# 快捷键测验已知 Bug 与兼容性问题

## Bug 1: Ctrl+_ 在 Mac 浏览器中无法直接触发

**现象**：题目显示"撤销上一次编辑操作"，答案为 Ctrl+_。但用户在 Mac 键盘上按下 `_`（下划线）时必须同时按 Shift，因此浏览器事件为 `Ctrl+Shift+-`，匹配失败。

**根因**：
- 终端中 `Ctrl+_` 是一个独立的 ASCII 控制码（0x1F），不需要 Shift
- 但在浏览器键盘事件中，`_`（下划线）是 Shift 修饰的键（`event.key === '_'` 且 `event.shiftKey === true`）
- 所以 `Ctrl+_` 在浏览器中实际上是 `Ctrl+Shift+-`

**已验证修复**：
```javascript
let shiftMatch = e.shiftKey === !!expected.shift;
if (expected.ctrl && expected.key === '_' && e.ctrlKey && e.shiftKey) {
  shiftMatch = true;
}
if (expected.ctrl && expected.key === '_' && e.ctrlKey && e.shiftKey &&
    ['_', '-', '='].includes(e.key)) {
  keyMatch = true;
}
```
关键点：必须同时放宽 `shiftMatch` 和 `keyMatch`；只增加下划线的 key 判断仍会被总匹配条件拦截。

备选方案：将题目改成 `Ctrl+/`，或在题目旁标注“Mac 下需按 Ctrl+Shift+-”。

## Bug 2: Alt+. 在不同输入法下键值被替换

**现象**：题目显示"插入上一条命令的最后一个参数"，答案为 Alt+.。用户按下 Alt+. 时，浏览器 `event.key` 返回的不是 `.` 而是 `≥`（或中文输入法下的 `。`），导致匹配失败。

**根因**：
- 某些键盘布局或输入法下，`.` 键的 `event.key` 会输出本地化字符（如 `≥`、`。`）
- 特别是在中文输入法（拼音、五笔等）激活状态下按下 `.` 键
- `event.code`（如 `Period`）始终不变，但 `event.key` 会变化

**已验证修复**：
- 用 `event.code === 'Period'` 识别物理句号键；同时接受 `event.key` 为 `.`, `≥`, `>`, `。`。
- 对 `expected.alt && expected.key === '.'` 的题目，若 `altKey` 为真且无 Ctrl，设置 `keyMatch = true`、`altMatch = true`，并不要因 `shiftKey` 为真而失败。
- Alt+B/F 同理使用 `event.code === 'KeyB'/'KeyF'`，因为 Option 可能把 `event.key` 转成 Unicode 特殊字符。

## Bug 3: Ctrl+F 和 →（右方向键）功能重复

**现象**：题库中同时存在：
- `Ctrl+F` → "光标向右移动一个字符"
- `→`（ArrowRight）→ "光标向右移动一个字符"

两个快捷键功能完全相同（在 Emacs 模式下），但作为不同题目出现。用户可能按 Ctrl+F 时刚好遇到 → 的题目被判错，反之亦然。

**修复方案**：
1. **删减题库**：两者只保留一个（通常保留方向键←→，因为更直观）
2. **重写描述**：如果两个都要保留，描述要区分：
   - `Ctrl+F`：在终端/Emacs 模式下光标右移
   - `→`：方向键光标右移（通用，Emacs 和 Vi 模式均可）
3. **排除相邻顺序**：如果都用，确保这两题不在相邻位置出现

## 输入法干扰通用处理建议

```javascript
// 输入法兼容的键值匹配
function normalizeKey(key) {
  const map = {
    '≥': '.', '。': '.',
    '《': '<', '》': '>',
    '？': '/', '、': '\\',
    '：': ';', '；': ';',
    '“': "'", '”': "'",
    '【': '[', '】': ']',
  };
  return map[key] || key;
}

// 在 checkShortcut 中使用：
const pk = normalizeKey(e.key.toLowerCase());
```

## 题库设计原则

1. **避免功能完全相同的快捷键同时作为不同题目**
2. **标明题目来源**：Emacs 模式 vs Vi 模式
3. **Mac 兼容性**：`_`、`{}`、`~` 等需要 Shift 的符号作为组合键键值时需标注兼容性
4. **知识题分离**：`!!`、`!$` 等无法键盘检测的单独作为知识题处理
5. **数量控制在 20-30 题**，太多会降低用户完成意愿
