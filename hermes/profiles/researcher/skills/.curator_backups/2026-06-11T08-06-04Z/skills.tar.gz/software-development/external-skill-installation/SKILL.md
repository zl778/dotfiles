---
name: external-skill-installation
description: Install third-party skills from GitHub repos or direct download URLs (not the Hermes skills hub). Covers download, runtime detection, runtime.conf, dependency checks, verification, and credential configuration.
version: 1.0.0
author: Hermes Agent
license: MIT
metadata:
  hermes:
    tags: [skills, installation, setup, credentials, hermès-env]
    related_skills: [hermes-agent, hermes-agent-skill-authoring]
---

# External Skill Installation

Workflow for installing skills from external sources (GitHub repositories, direct download URLs) into Hermes — skills that are NOT in the Hermes skills hub and cannot be installed via `hermes skills install <hub-id>`.

## When to Use

- User asks to install a skill, and `hermes skills search <name>` returns nothing
- User provides a direct download URL (GitHub archive, raw SKILL.md link)
- User asks to install a skill from a specific GitHub repository

## Workflow

```
Download → Install → Check deps → Detect runtime → 
  Write runtime.conf → Verify (doc) → Test → Configure credentials
```

### 1. Download

```bash
# From GitHub main branch archive
curl -sL -o skill.zip "https://github.com/<user>/<repo>/archive/refs/heads/main.zip"
unzip -q skill.zip
# Unzipped dir is usually <repo>-main/ or <repo>-<branch>/
```

Prefer pinning to a specific release tag when one exists.

### 2. Install to Hermes

```bash
mkdir -p ~/.hermes/skills/<name>
cp -r <downloaded_dir>/* ~/.hermes/skills/<name>/
```

The skill name in `~/.hermes/skills/<name>/` should match the `name` field in the skill's SKILL.md frontmatter.

### 3. Check Dependencies

Run the skill's CLI tool with the `doc` subcommand (or `--help`) to catch missing runtime dependencies:

```bash
# Try Python first
python3 ~/.hermes/skills/<name>/scripts/*.py doc 2>&1
```

Common missing dependencies and their fixes:

| Error | Fix |
|-------|-----|
| `ModuleNotFoundError: No module named 'requests'` | `pip3 install requests` |
| `ModuleNotFoundError: No module named '...'` | `pip3 install <module>` |
| `command not found: python` | Try `python3` |

Runtime priority order: **Python → Node.js → Shell (sh/bash/PowerShell)**. If Python fails, try Node.js (`node <js-cli> doc`), then shell fallback.

### 4. Detect Runtime & Write runtime.conf

After the CLI works with one runtime, persist it:

```bash
SKILL_DIR=~/.hermes/skills/<name>
echo "Runtime: Python" > $SKILL_DIR/runtime.conf
echo "Command: python3 $SKILL_DIR/scripts/<cli-file>.py" >> $SKILL_DIR/runtime.conf
```

`runtime.conf` is read on every skill load. Without it, the agent runs the full detection procedure each time. The file format is two lines:

```
Runtime: <name>
Command: <full command with args>
```

Examples for each runtime:

| Runtime | runtime.conf |
|---------|-------------|
| Python | `Runtime: Python` / `Command: python3 <skill_dir>/scripts/foo.py` |
| Node.js | `Runtime: Node.js` / `Command: node <skill_dir>/scripts/foo.js` |
| Bash | `Runtime: Bash` / `Command: bash <skill_dir>/scripts/foo.sh` |
| PowerShell | `Runtime: PowerShell` / `Command: powershell -ExecutionPolicy Bypass -File <skill_dir>/scripts/foo.ps1` |

### 5. Verify with doc command

```bash
python3 ~/.hermes/skills/<name>/scripts/*.py doc
```

The `doc` command is local-only (no network). A clean output confirms the CLI is functional.

### 6. Test with a real operation

```bash
python3 ~/.hermes/skills/<name>/scripts/*.py search "test query" --max_results 1
```

If the test fails, check:
- API connectivity (DNS, network)
- Whether the service is accessible from your region
- Rate limits (try without API key first, then with key)

### 7. Configure Credentials

If the skill needs an API key, see `references/credential-file-writing-workaround.md` for how to write `.env` files when Hermes' secret redaction intercepts the key.

## Pitfalls

1. **Secret redaction truncates API keys in terminal commands.** When using `echo`/`printf`/`cat` to write `.env` files, the security layer intercepts the key and writes only a truncated version. Do NOT use shell commands for credential files. Use the Python helper script pattern documented in `references/credential-file-writing-workaround.md`.

2. **runtime.conf must exist before first skill load.** The SKILL.md's "Platform Detection" section tells the agent to read `runtime.conf` first. If it's missing, the agent falls back to runtime detection every activation, wasting tool calls.

3. **Assume `python` may not exist on macOS.** On macOS, `python` is absent by default; `python3` is the correct executable. Check both.

4. **The skills hub may be slow or time out.** `hermes skills search` and `hermes skills browse` can time out. If they do, try the direct install approach using a GitHub URL.

5. **Permissions on `.env` files.** Always set `chmod 600` on files containing API keys.

## Verification Checklist

- [ ] Skill directory exists at `~/.hermes/skills/<name>/`
- [ ] `SKILL.md` is present with valid frontmatter
- [ ] `runtime.conf` exists with correct runtime and command
- [ ] CLI `doc` command runs without errors
- [ ] Real operation (search, extract, etc.) returns valid results
- [ ] `.env` with API key configured and readable (tested with a real call)
- [ ] Cleaned up temporary download files
