---
name: hermes-update-manual
description: "手动更新 Hermes Agent — 当 hermes update 因网络/API 问题失败时的备用方案"
version: 1.0.0
author: Hermes Agent
platforms: [macos, linux]
---

# Hermes 手动更新

当 `hermes update` 因为 API 连接失败（如 `APIConnectionError`）无法正常更新时，使用此方案通过 git + pip 直接手动更新。

## 触发条件

- `hermes update` 报 `APIConnectionError` 或网络相关错误
- `hermes --version` 显示旧版本且有大量 commits behind
- git 处于 detached HEAD 状态

## 修复步骤

```bash
# 1. 进入 Hermes 代码目录
cd ~/.hermes/hermes-agent

# 2. 切换到 main 分支（从 detached HEAD 恢复）
git checkout main

# 3. 拉取最新代码
git pull origin main

# 4. 激活虚拟环境并重新安装
source venv/bin/activate
pip install -e .
```

## 验证

```bash
hermes --version
# 应显示: Hermes Agent v0.16.0 或更新版本
# Up to date ✅
```

## 常见原因

1. **git detached HEAD** — 之前更新中断，代码停留在旧 commit 上
2. **代理/网络问题** — API 提供商不可达（如 DeepSeek、OpenAI 等被代理干扰）
3. **Clash Verge 等代理工具** — 需要在全局拓展脚本中为 API 域名添加直连规则：

```js
addRule("DOMAIN-SUFFIX,deepseek.com,DIRECT");
addRule("DOMAIN-SUFFIX,api.deepseek.com,DIRECT");
```
