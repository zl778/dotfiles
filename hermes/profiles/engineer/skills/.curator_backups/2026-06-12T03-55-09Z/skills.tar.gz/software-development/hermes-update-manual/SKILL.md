---
name: hermes-update-manual
description: "Hermes Agent 更新管理 — 手动更新、post-update 桌面应用处理、macOS 桌面端常见问题"
version: 2.0.0
author: Hermes Agent
platforms: [macos, linux]
---

# Hermes 更新管理

涵盖 `hermes update` 正常流程的补充步骤，以及当自动更新失败时的 git 手动更新方案。

## 触发条件

- 执行 `hermes update` 后需要处理桌面端
- `hermes update` 报 `APIConnectionError` 或网络相关错误
- `hermes --version` 显示旧版本且有大量 commits behind
- git 处于 detached HEAD 状态

---

## 1. 正常更新后的桌面端处理

`hermes update` 成功执行后，**不会自动**将新版 Hermes.app 安装到 `/Applications/`。新版会构建在：

```
~/.hermes/hermes-agent/apps/desktop/release/mac-arm64/Hermes.app
```

### 安装新版到 /Applications/

```bash
# ❌ 错误做法 — cp -R 对已存在的 .app 目录是合并而非替换
cp -R ~/.hermes/hermes-agent/apps/desktop/release/mac-arm64/Hermes.app /Applications/Hermes.app

# ✅ 正确做法 — 先删旧的，再复制
rm -rf /Applications/Hermes.app
cp -R ~/.hermes/hermes-agent/apps/desktop/release/mac-arm64/Hermes.app /Applications/Hermes.app
```

**重要**：macOS 上 `cp -R` 对已存在的目录执行**合并**（merge），不会替换已有文件。新旧文件混在一起，二进制不会被更新。必须先用 `rm -rf` 删除旧 .app。

### 验证安装成功

```bash
# 对比 checksum，确认是同一份
md5 -q ~/.hermes/hermes-agent/apps/desktop/release/mac-arm64/Hermes.app/Contents/MacOS/Hermes
md5 -q /Applications/Hermes.app/Contents/MacOS/Hermes
# 两个 MD5 应一致
```

### 设置中文界面

```bash
hermes config set display.language zh
```

官方 Hermes Desktop 内置完整的多语言支持：简体中文 (`zh`)、繁体中文 (`zh-hant`)、日语 (`ja`)、英语 (`en`)。设置后重启桌面应用即可。

---

## 2. 清除冗余的应用（macOS）

`/Applications/` 下可能出现多个 Hermes 相关应用：

| 应用 | 说明 | 可否删除 |
|------|------|----------|
| `Hermes.app` | 官方 Desktop 应用，Electron 构建 | ❌ 主应用 |
| `Hermes (Fixed).app` | 手动创建的 shell 脚本包装器 | ✅ 可删 |
| `Hermes Launcher.app` 等 | 各类自定义启动器 | ✅ 看情况 |

### 什么是 Hermes (Fixed).app？

它是一个手动创建的 macOS .app 包装器，里面只有一个 shell 脚本（`HermesLauncher`），作用是设置 `HERMES_PYTHON` 环境变量后调用 `open /Applications/Hermes.app`。

**出现原因**：旧版 Hermes Desktop 启动 TUI gateway 后台进程时，会使用系统默认 Python（可能缺少 dotenv 等依赖包），导致 Voice 转录报 "Timed out connecting to Hermes backend" 错误。设置 `HERMES_PYTHON=~/.hermes/hermes-agent/venv/bin/python3` 可修复。

**清理时机**：如果新版已修复此问题，或已改用 `~/bin/hermes-app` 脚本启动，可以安全删除包装器。

---

## 3. 手动更新（当 hermes update 失败时）

### 修复步骤

```bash
# 1. 进入 Hermes 代码目录
cd ~/.hermes/hermes-agent

# 2. 切换到 main 分支（从 detached HEAD 恢复）
git checkout main

# 3. 拉取最新代码
git pull origin main

# 4. 激活虚拟环境并重新安装
source venv/bin/activate
pip install -e .
```

### 验证

```bash
hermes --version
# 应显示最新版本
```

### 常见原因

1. **git detached HEAD** — 之前更新中断，代码停留在旧 commit 上
2. **代理/网络问题** — API 提供商不可达（如 DeepSeek、OpenAI 等被代理干扰）
3. **Clash Verge 等代理工具** — 需要在全局拓展脚本中为 API 域名添加直连规则：

```js
addRule("DOMAIN-SUFFIX,deepseek.com,DIRECT");
addRule("DOMAIN-SUFFIX,api.deepseek.com,DIRECT");
```

---

## 陷阱与注意事项

- `cp -R` 不会替换已存在的 .app — 先 `rm -rf` 再复制
- `hermes update` 构建 Desktop 但不安装 — 需要手动复制
- `HERMES_PYTHON` 环境变量可以修复桌面端 TUI gateway Python 依赖问题
- 更新后如果 Desktop 语言没有变化，检查 `hermes config get display.language` 是否已设
